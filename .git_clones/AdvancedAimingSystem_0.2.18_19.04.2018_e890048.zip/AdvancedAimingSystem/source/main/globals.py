# ---------------------- #
#    Global variables    #
# ---------------------- #
g_globals = {
	'appConfigFile': None,
	'appConfigReader': None,
	'appDefaultConfig': None,
	'appLoadingMessage': None
}
